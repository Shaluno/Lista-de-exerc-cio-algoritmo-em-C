#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<string.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-05 -  : Login simples --> Uma escola criou um sistema simples para acesso � biblioteca digital.\n"
			"\nO aluno deve informar usu�rio e senha corretos para entrar no sistema.\n"
			"\nO programa deve verificar se os dados digitados est�o corretos e mostrar uma mensagem de acesso permitido ou negado.\n");
	printf("\n************************************************************************** ");
	
	
//In�cio do c�digo

char usuarioCorreto[15] = "willians";
int senhaCorreta = 202610;

char usuario[15];
int senha;

	printf("\n\nUsu�rio: ");
		scanf("%s", usuario);
	printf("\nSenha: ");
		scanf("%d", &senha);
	
	
	if(strcmp(usuario, usuarioCorreto) != 0|| senha != senhaCorreta){
		printf("\n\nUsu�rio ou Senha INCORRETOS!");
	}else{
		printf("\nAcesso LIBERADO!");
	}	
	
	return 0;
}
