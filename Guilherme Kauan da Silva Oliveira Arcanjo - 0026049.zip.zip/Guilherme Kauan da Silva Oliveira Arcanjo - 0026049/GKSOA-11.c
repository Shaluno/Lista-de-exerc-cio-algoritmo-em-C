#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-11 -   Pode votar? --> Um sistema de cadastro eleitoral precisa verificar se uma pessoa j� possui idade para votar."
			"\nO usu�rio informa sua idade, e o programa deve dizer se ele pode ou n�o votar.\n");
	printf("\n************************************************************************** ");

//In�cio do c�digo

int idade;

printf("\n\n     SISTEMA ELEITORAL      \n\n");

	printf("PARA DESCOBRIR SE VOC� J� PODE VOTAR, SER� NECESS�RIO INFORMAR SUA IDADE!\n");
	printf("\nINFORME SUA IDADE: ");
		scanf("%d", &idade);
		
		if(idade >= 18){
			printf("\nVOC� PODE VOTAR!");
		}else{
			printf("\nVOC� N�O PODE VOTAR!");
		}
		
 	return 0;
}
