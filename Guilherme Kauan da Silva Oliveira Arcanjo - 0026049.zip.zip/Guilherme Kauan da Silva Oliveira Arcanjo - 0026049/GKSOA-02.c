#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-02 - Quantas caixas cabem dentro do caminh�o --> Uma empresa de log�stica precisa calcular quantas caixas podem ser transportadas\n"
           "em um caminh�o sem ultrapassar o espa�o dispon�vel.\n\n"
           "O sistema deve receber as dimens�es do caminh�o e das caixas\n ");
	printf("\n************************************************************************** ");
	
	
//In�cio do c�digo

int alturaCaixa, larguraCaixa, comprimentoCaixa;
int alturaCamin, larguraCamin, comprimentoCamin;
int alturaQtd, larguraQtd, comprimentoQtd, total;

printf("\n\n             IN�CIO                \n\n");
printf("       DIMENS�ES CAMINH�O              \n\n");
	
	printf("Altura: ");
		scanf("%d", &alturaCamin);
	printf("\nLargura: ");
		scanf("%d", &larguraCamin);
	printf("\nComprimento: ");
		scanf("%d", &comprimentoCamin);
		
printf("\n\n        DIMENS�ES CAIXA              \n\n");		
		
	printf("Altura: ");
		scanf("%d", &alturaCaixa);
	printf("\nLargura: ");
		scanf("%d", &larguraCaixa);
	printf("\nComprimento: ");
		scanf("%d", &comprimentoCaixa);	
		
			alturaQtd = alturaCamin / alturaCaixa;
			larguraQtd = larguraCamin / larguraCaixa;
			comprimentoQtd = comprimentoCamin / comprimentoCaixa;
			
		total = alturaQtd * larguraQtd * comprimentoQtd;
				
	printf("\nQuantidade total de caixas: %d\n", total);
		
return 0;			
 
}
