#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include <windows.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-04 -  O Sensor do Parque Tem�tico -->  Sistema de seguran�a de uma nova montanha-russa em um parque de"
           " divers�es. Por motivos de seguran�a, existe uma altura m�nima de 140 cent�metros (1,40m) para poder entrar no brinquedo.\n");
	printf("\n************************************************************************** ");
	
	
//In�cio do c�digo

int altura;
	
	printf("\n\nDigite a sua altura: ");
		scanf("%d", &altura);
		
	printf("\n\n      VERIFICANDO ALTURA . . .     \n\n");
	
		sleep(2);
	
		if(altura >= 140){
			printf("Luz verde - - LIBERADO!");
		}else{
			printf("Luz vermelha - - BARRADO!");
		}
   
   return 0;
}
