#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-03 -  M�ltiplo de 3 e/ou 5 --> Uma lanchonete criou uma promo��o especial.\n"
			"\nSe o n�mero do pedido for m�ltiplo de 3, o cliente ganha um refrigerante.\n"
			"Se for m�ltiplo de 5, ganha uma sobremesa.\n"
			"Se for m�ltiplo dos dois, ganha os dois brindes.\n"
			"\nO programa deve verificar o n�mero do pedido e informar qual pr�mio o cliente ganhou.\n");
	printf("\n************************************************************************** ");
	
	
//In�cio do c�digo

int pedido;

printf("\n\n      Lanchonete X-Tudo e Mais um Pouco             \n\n");

	printf("\nDigite o n�mero do pedido seu pedido e concorra � um brinde secreto e exclusivo!: ");
		scanf("%d", &pedido);
		
	if(pedido % 3 == 0 && pedido % 5 == 0){
		printf("\n\nParab�ns!! Voc� ganhou um Refrigerante e uma Sobremesa!\n");
		printf("\n\nCupom: 1010\n");
		printf("\nEsse cupom te garante o resgate GRATUITO dos seus brindes , dirija-se ao balc�o para resgat�-los!\n");	
	}else if(pedido % 5 == 0){
		printf("\n\nParab�ns!! Voc� ganhou uma Sobremesa!\n");
		printf("\n\nCupom:9099\n");
		printf("Esse cupom te garante o resgate GRATUITO do seu brinde , dirija-se ao balc�o para resgat�-lo!\n");
	}else if(pedido % 3 == 0){
		printf("\n\nParab�ns!! Voc� ganhou um Refrigerante!\n");
		printf("\n\nCupom: 8088\n");
		printf("\nEsse cupom te garante o resgate GRATUITO do seu brinde , dirija-se ao balc�o para resgat�-lo!\n");
		
	}else{
		printf("Que pena! Hoje n�o rolou brinde. . . Mas o lanche t� caprichado!");
	}

return 0;


}
