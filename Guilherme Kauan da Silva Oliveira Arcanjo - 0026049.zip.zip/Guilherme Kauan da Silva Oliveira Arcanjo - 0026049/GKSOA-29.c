#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-29 - Quantidade de n�meros �mpares digitados"
			"\nUma pesquisa escolar precisa analisar n�meros digitados pelos participantes."
			"\nO programa deve pedir 10 n�meros e informar quantos deles s�o �mpares.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo



int num[10];
int i = 0, contador = 0;

    while(i < 10){
        printf("Digite o %d� n�Smero: ", i + 1);
        scanf("%d", &num[i]);

        if(num[i] % 2 != 0){
            contador++;
        }

        i++;
    }

    printf("\nQuantidade de n�meros �mpares: %d\n", contador);

    return 0;
}
