#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-18 - Contagem regressiva --> Uma competi��o escolar utiliza uma contagem regressiva antes da largada."
			"\nO programa deve mostrar os n�meros de 10 at� 1 na tela.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo
 int i;
 
 	for(i = 10; i >= 1; i--){
 		printf("\n%d\n", i);
	 }
	 
	 
return 0;

}
