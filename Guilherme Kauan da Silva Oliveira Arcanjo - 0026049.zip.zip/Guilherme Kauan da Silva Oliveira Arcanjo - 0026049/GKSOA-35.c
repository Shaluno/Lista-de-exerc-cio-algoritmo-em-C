#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-35 - Menu com op��o de sair"
			"Fa�a um programa mostrando um menu de op��es. Ele fica pedindo para o usu�rio escolher entre duas op��es."
			"(digitar 1 para mostrar uma mensagem ou 2 para sair) at� que o usu�rio escolha a op��o 2. O fluxo de execu��o � o "
			"seguinte:"
			"\nO programa exibe o menu com as op��es: ''1 - Mensagem'' ou ''2 - Sair''."
			"\nSe o usu�rio escolher 1, ele imprime a mensagem ''Voc� escolheu a mensagem!''."
			"\nO programa continuar� executando o menu at� que o usu�rio escolha 2 para sair.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int opcao;

    do{
        printf("\n===== MENU =====\n");
        printf("1 - Mensagem\n");
        printf("2 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if(opcao == 1){
            printf("Voce escolheu a mensagem!\n");
        }
        else if(opcao == 2){
            printf("Saindo...\n");
        }
        else{
            printf("Opcao invalida!\n");
        }

    } while(opcao != 2);

    return 0;
}
