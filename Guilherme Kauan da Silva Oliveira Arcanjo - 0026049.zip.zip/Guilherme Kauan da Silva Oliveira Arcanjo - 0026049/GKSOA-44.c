#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-44 - A Calculadora de Bolso de 4 Opera��es --> Voc� foi desafiado a criar o motor l�gico de uma " 
			"calculadora de bolso bem simples, daquelas que s� fazem as quatro opera��es b�sicas."
			"\nO algoritmo deve receber dois n�meros reais (ex: 10 e 5) e um caractere "
			"representando a opera��o matem�tica ('+', '-', '*', '/'). Use o Switch...Case para analisar o "
			"caractere da opera��o e exibir o resultado do c�lculo correspondente."
			"\n\nCaso receba um s�mbolo diferente dos quatro: Exiba ''Opera��o matem�tica n�o reconhecida''\n");
	printf("\n**************************************************************************\n\n");

float num1, num2;
char op;

    printf("Digite o primeiro n�mero: ");
    scanf("%f", &num1);

    printf("Digite o segundo n�mero: ");
    scanf("%f", &num2);

    printf("Digite a opera��o (+, -, *, /): ");
    scanf(" %c", &op); // espa�o antes do %c � importante

    switch(op){

        case '+':
            printf("Resultado: %.2f\n", num1 + num2);
            break;

        case '-':
            printf("Resultado: %.2f\n", num1 - num2);
            break;

        case '*':
            printf("Resultado: %.2f\n", num1 * num2);
            break;

        case '/':
            if(num2 != 0){
                printf("Resultado: %.2f\n", num1 / num2);
            } else {
                printf("Erro: divis�o por zero!\n");
            }
            break;

        default:
            printf("Operacao matem�tica n�o reconhecida\n");
    }

    return 0;
    
}
