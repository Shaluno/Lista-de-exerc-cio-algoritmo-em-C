#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-15 - Soma dos 100 primeiros n�meros naturais"
			"\nUma loja deseja calcular rapidamente a soma de uma sequ�ncia de n�meros para um relat�rio simples."
			"\nO programa deve calcular a soma dos n�meros de 1 at� 100 utilizando um la�o for.	\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo
 int i;
 int soma = 0;
 
 	for(i = 1; i<= 100; i++){
 		soma = soma + i;
	 }
	
	printf("\nO resultado da soma dos n�meros naturais de 1 a 100 �: %d.", soma);
	 
return 0;

}
