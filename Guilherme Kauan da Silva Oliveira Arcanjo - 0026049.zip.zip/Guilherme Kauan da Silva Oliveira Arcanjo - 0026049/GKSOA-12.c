#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-12 - Notas e aprova��o --> Uma escola deseja automatizar a verifica��o das notas dos alunos."		
			"\nO sistema deve receber a m�dia final do estudante e informar se ele foi aprovado, em recupera��o ou reprovado.\n");
	printf("\n************************************************************************** ");

//In�cio do c�digo

float n1, n2, n3, n4, mediaFinal;

	printf("\nDIGITE SUA NOTA DO 1� BIMESTRE: ");
		scanf("%f", &n1);
	printf("\nDIGITE SUA NOTA DO 2� BIMESTRE: ");
		scanf("%f", &n2);
	printf("\nDIGITE SUA NOTA DO 3� BIMESTRE: ");
		scanf("%f", &n3);
	printf("\nDIGITE SUA NOTA DO 4� BIMESTRE: ");
		scanf("%f", &n4);
		
		mediaFinal = (n1 + n2 + n3 + n4) / 4;
		
			if(mediaFinal >= 7){
				printf("\nALUNO APROVADO!");
			}else if(mediaFinal < 5){
				printf("\nALUNO REPROVADO!");
			}else{
				printf("\nALUNO EM RECUPERA��O!");
				printf("\nCOMPARE�A A SECRETARIA PARA MAIS INFORMA��ES!");
			}
			
			printf("\nM�DIA FINAL: %.1f.", mediaFinal);
	
		return 0;

}
