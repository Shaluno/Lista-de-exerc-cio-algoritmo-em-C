#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-24 -  Soma de n�meros at� digitar zero."
			"\nUm caixa simples de mercado precisa somar valores digitados pelo operador."
			"\nO programa deve continuar recebendo n�meros at� que o usu�rio digite 0 e, ao final, mostrar a soma total.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo
int numero;
int soma = 0;

	printf("\nDigite um n�mero: (0 PARA ENCERRAR) ");
		scanf("%d", & numero);
		
		while(numero != 0){
			soma = soma + numero;
			printf("\nDigite um n�mero: (0 PARA ENCERRAR) ");
			scanf("%d", & numero);		
		}
		 
	printf("\nTotal: %d", soma);
		 


return 0;


}
