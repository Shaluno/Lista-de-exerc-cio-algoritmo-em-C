#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-25 -  Senha correta --> Um sistema de acesso precisa garantir que apenas usu�rios autorizados entrem."
			"\nO programa deve solicitar a senha repetidamente at� que o usu�rio digite a senha correta.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

char nome [25];
char senhaCo [12] = "brasil2026#";
char senha [12];


	printf("\nDIGITE SEU 1� NOME: ");
		scanf("%s", nome);
		
	printf("\nOl� %s!", nome);
	
	printf("\n\nDIGITE SUA SENHA: ");
		scanf("%s", senha);	
		
		while(strcmp(senha, senhaCo) !=0){
			printf("\n\nSENAH INCORRETA! DIGITE NOVAMENTE!: ");
				scanf("%s", senha);	
		}
		
		printf("\nENTRANDO!");
		

return 0;


}
