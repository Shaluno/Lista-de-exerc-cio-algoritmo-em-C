#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-34 - Tabuada de um n�mero --> Um estudante quer praticar multiplica��o usando a estrutura do...while."
			"\nO programa deve receber um n�mero e exibir sua tabuada de 1 at� 10.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int numero;
int i = 1;

	printf("\nDigite um n�mero e descubra sua tabuada at� 10: ");
		scanf("%d", &numero);
		
	do{
		
		printf("\n%d x %d = %d", numero, i, numero * i);
		i++;
		
	} while(i <= 10);



return 0;

}
