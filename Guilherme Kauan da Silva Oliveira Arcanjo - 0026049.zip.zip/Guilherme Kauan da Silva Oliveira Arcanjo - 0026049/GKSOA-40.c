#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-40 - Validar n�mero entre 1 e 5 --> Um jogo educativo aceita apenas n�veis de dificuldade entre 1 e 5."
			"\nO programa deve pedir ao usu�rio um n�mero dentro desse intervalo e continuar solicitando enquanto o valor digitado for inv�lido..\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

 int numero;

    do{
        printf("Digite um n�mero entre 1 e 5: ");
        scanf("%d", &numero);

        if(numero < 1 || numero > 5){
            printf("Valor inv�lido! Tente novamente.\n");
        }

    } while(numero < 1 || numero > 5);

    printf("N�mero valido!\n");

    return 0;


}
