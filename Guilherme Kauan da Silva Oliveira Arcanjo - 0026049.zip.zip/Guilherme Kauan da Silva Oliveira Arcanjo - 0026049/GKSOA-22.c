#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-22 - N�meros de Fibonacci (n termos)."
			"\nUm clube de matem�tica quer estudar a famosa sequ�ncia de Fibonacci."
			"\nO programa deve pedir um valor n e mostrar os primeiros termos da sequ�ncia.");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo
int i, n;
int a = 0, b = 1, c;

    printf("Quantos termos deseja ver? ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++){
        printf("%d ", a);

        c = a + b;
        a = b;
        b = c;
    }

    return 0;
}


