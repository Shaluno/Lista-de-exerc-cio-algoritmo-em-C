#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-07 - Ano bissexto --> Uma agenda digital precisa descobrir se determinado ano ter� 366 dias."
			"\nO usu�rio informa um ano, e o programa deve verificar se ele � bissexto ou n�o. \n");
	printf("\n************************************************************************** ");

//In�cio do c�digo

int ano;

	printf("\n\nDescubra se o ano � bissexto");
	printf("\nANO: ");
		scanf("%d", & ano);
		
		if(ano % 400 == 0){
			printf("%d � bissexto!", ano);
		}else if (ano % 100 == 0){
			printf("%d N�O � bissexto!", ano);
		}else if(ano % 4 == 0){
			printf("%d � bissexto!", ano);	
		}else{
			printf("%d N�O � bissexto!", ano);
		}
	
	return 0;


}
