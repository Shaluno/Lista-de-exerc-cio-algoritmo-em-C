#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-30 - Soma dos pares entre 1 e 100."
			"\nUm professor prop�s um desafio para calcular apenas os n�meros pares de uma sequ�ncia."
			" O programa deve somar todos os n�meros pares entre 1 e 100 utilizando while.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int i = 1;
int soma = 0;

	while(i <= 100){
		if(i % 2 == 0){
			soma = soma + i;
		}
			i++;
	}
	
	printf("\n o resultado da soma dos pares �: %d", soma);

return 0;

}
