#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-08 - N�mero positivo ou negativo --> Um aplicativo financeiro registra lucros e preju�zos."
			"\nValores positivos representam lucro e valores negativos representam preju�zo."
			"\nO programa deve receber um n�mero e informar se ele � positivo, negativo ou zero. \n");
	printf("\n************************************************************************** ");

//In�cio do c�digo
 int numero;
 
 printf("\n\n      FINANCIAL CLAIN             \n\n");


	printf("\n\nDigite o n�mero e descruba o resulatdo: ");
		scanf("%d", & numero);
		
		if(numero > 0){
			printf("\nN�mero Positivo -- LUCRANDO!!!");
		}else if(numero < 0){
			printf("\nN�mero Negativo -- CUIDADO - PREJU�ZO ENCONTRADO!!!");
		}else{
			printf("\nN�mero Neutro -- 0 x 0 no placar - Aten��o!!!");
		}

	return 0;

}
