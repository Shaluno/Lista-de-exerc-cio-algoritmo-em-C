#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-43 - A Central do Brinquedo Eletr�nico. --> O Exerc�cio: Desenvolva a l�gica do urso." 
			"\nO algoritmo deve receber uma palavra (texto) com a cor que acendeu e exibir a fala do brinquedo:"
			"\n\n'Verde': O urso diz: 'Vamos brincar l� fora!'"
			"\n'Amarelo': O urso diz: 'Estou ficando com soninho...'"
			"\n'Vermelho': O urso diz: 'Estou com fome, hora do lanche!'"
			"\n\nCaso seja outra cor: O urso apenas pisca as luzes (Mensagem: 'Cor desconhecida')\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo


char cor[20];
    int opcao;

    printf("Digite a cor: ");
    scanf("%s", cor);

    if(strcmp(cor, "Verde") == 0){
        opcao = 1;
    }
    else if(strcmp(cor, "Amarelo") == 0){
        opcao = 2;
    }
    else if(strcmp(cor, "Vermelho") == 0){
        opcao = 3;
    }
    else{
        opcao = 0;
    }

    switch(opcao){

        case 1:
            printf("O urso diz: Vamos brincar la fora!\n");
            break;

        case 2:
            printf("O urso diz: Estou ficando com soninho...\n");
            break;

        case 3:
            printf("O urso diz: Estou com fome, hora do lanche!\n");
            break;

        default:
            printf("Cor desconhecida\n");
    }

    return 0;

}
