#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-39 - Confirmar sa�da com 's'. --> Um programa de cadastro possui um menu simples de op��es."
			"\nAp�s cada opera��o, o sistema deve perguntar se o usu�rio deseja sair. O menu continuar� aparecendo at� "
			"que o usu�rio digite a letra �s�.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo


char sair;

    do{
        printf("\n===== MENU =====\n");
        printf("1 - Opcao 1\n");
        printf("2 - Opcao 2\n");

        printf("Escolha uma opcao: ");
        int opcao;
        scanf("%d", &opcao);

        if(opcao == 1){
            printf("Voce escolheu a opcao 1\n");
        }
        else if(opcao == 2){
            printf("Voce escolheu a opcao 2\n");
        }
        else{
            printf("Opcao invalida!\n");
        }

        printf("\nDeseja sair? (s/n): ");
        scanf(" %c", &sair); // espa�o antes do %c � importante

    } while(sair != 's');

    printf("Encerrando o programa...\n");

    return 0;

}
