#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-16 - N�meros pares de 0 a 50 --> Um jogo educativo precisa mostrar apenas os" 
			" n�meros pares para ensinar matem�tica b�sica"
			"\nO programa deve exibir todos os n�meros pares entre 0 e 50. \n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo
 int i; 
 
 	for(i = 0; i <= 50; i++){
 		if(i % 2 == 0){
 			printf("\n%d\n", i);
		 }
	 }
	 
	 
return 0;

}
