#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-09 - Par ou �mpar --> Em um jogo educativo, o participante digita um  n�mero para descobrir sua classifica��o."
			"\nO programa deve verificar se o n�mero informado � par ou �mpar. \n");
	printf("\n************************************************************************** ");

//In�cio do c�digo

int numero;

	printf("\n\nDigite um n�mero e descubra se ele � PAR ou �MPAR: ");
		scanf("%d", &numero);
		
		if(numero % 2 == 0){
			printf("\nN�MERO PAR!");
		}else{
			printf("\nN�MERO �MPAR!");
		}
		
	return 0;



	
	
}

