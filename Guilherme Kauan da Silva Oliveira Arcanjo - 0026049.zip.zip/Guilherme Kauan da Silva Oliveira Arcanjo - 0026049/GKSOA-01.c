#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-01 - Tipo de tri�ngulo --> Uma fabr�ca de estruturas met�licas produz suportes em formato de tri�ngulo para eventos e constru��es"
           "Antes da fabrica��o, o sistema precisa verificar o tipo do tri�ngulo com base nas medidas informadas pelo operador.\n\n"
           "O programa deve receber os tres lados do triangulo e informar se ele �:\n"
           "- Equil�tero -> todos os lados iguais;\n"
           "- Is�sceles  -> dois lados iguais;\n"
           "- Escaleno   -> todos os lados diferentes.   \n ");
	printf("\n************************************************************************** ");
	
	
//In�cio do c�digo

	float a, b, c;
	
	printf("\n\n             IN�CIO                \n\n");
	
		printf("Lado A: ");
			scanf("%f", &a);
		printf("Lado B: ");
			scanf("%f", &b);
		printf("Lado C: ");
			scanf("%f", &c);
			
	if(a == b && b == c){
		printf("\nTri�ngulo EQUIL�TERO");
	}else if(a == b || a == c || b == c){
		printf("\nTri�ngulo IS�CELES");
	}else{
		printf("Tri�ngulo ESCALENO");
	}
	
	
	return 0;	
	
//Fim do c�digo

}
