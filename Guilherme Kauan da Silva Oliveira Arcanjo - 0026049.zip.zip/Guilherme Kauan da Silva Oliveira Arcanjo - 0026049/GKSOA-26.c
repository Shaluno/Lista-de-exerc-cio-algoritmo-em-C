#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-26 - Verificar se um n�mero � positivo --> Um sistema financeiro s� aceita valores positivos para cadastro."
			"\nO programa deve continuar pedindo n�meros at� que o usu�rio digite um n�mero positivo.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int numero;


	printf("\nDigite um n�mero : ");
		scanf("%d", &numero);
		
	while(numero <= 0){
		printf("\nDigite um n�mero (positivo): ");
			scanf("%d", &numero);
	}
	
	printf("\nFim do programa!");

return 0;


}
