#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-27 - Tabuada com while --> Um aluno deseja praticar multiplica��o usando repeti��o."
			"\nO programa deve receber um n�mero e mostrar sua tabuada de 1 a 10 utilizando while.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int numero, i = 1;


	printf("\nDigite um n�mero : ");
		scanf("%d", &numero);
		
	while(i <= 10){
		printf("\n%d x %d = %d\n", numero, i, numero * i);
			i++;
	}

return 0;


}
