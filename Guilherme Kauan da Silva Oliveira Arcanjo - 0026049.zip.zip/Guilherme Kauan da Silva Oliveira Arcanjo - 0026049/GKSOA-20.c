#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-20 - M�ltiplos de 3 entre 1 e 30 --> Um aplicativo educacional deseja destacar os n�meros m�ltiplos de 3 para os alunos."
			"O programa deve listar todos os m�ltiplos de 3 entre 1 e 30.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo
 int i;
 
 	for(i = 1; i <= 30; i++){
		if(i % 3 == 0){
			printf("\n%d\n", i);
		}
	 }
	 
	 
return 0;

}
