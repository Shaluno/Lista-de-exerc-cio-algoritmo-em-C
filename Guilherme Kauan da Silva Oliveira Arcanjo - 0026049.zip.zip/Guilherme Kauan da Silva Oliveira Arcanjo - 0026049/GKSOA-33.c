#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-33 - Contar de 1 a 10 --> Uma escola est� ensinando estruturas de repeti��o para iniciantes em programa��o."
			"\nO programa deve imprimir os n�meros de 1 at� 10, um por linha, utilizando do...while.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int i = 1;

do{
	printf("\n%d", i);
	i++;
	
	}while(i <= 10);

return 0;

}
