#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-41 - Ler n�meros e mostrar o maior (at� digitar negativo)."
			"\nUma pesquisa escolar registra notas positivas dos participantes."
			"\nO programa deve continuar recebendo n�meros at� que um valor negativo seja digitado. Ao final, deve"
			"cmostrar qual foi o maior n�mero positivo informado..\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int numero, maior;
int primeiro = 1;

    do{
        printf("Digite um n�mero (negativo para parar): ");
        scanf("%d", &numero);

        if(numero >= 0){
            if(primeiro){
                maior = numero;
                primeiro = 0;
            }
            else if(numero > maior){
                maior = numero;
            }
        }

    } while(numero >= 0);

    if(primeiro){
        printf("Nenhum n�mero positivo foi digitado.\n");
    } else {
        printf("Maior n�mero digitado: %d\n", maior);
    }

    return 0;
}

