#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-32 - Menu at� escolher sair --> Um caixa eletr�nico simples apresenta op��es ao usu�rio."
			"\nO programa deve exibir um menu repetidamente at� que a op��o �sair� seja escolhida\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int opcao = 0;

    while(opcao != 4){

    	printf("\n===== MENU =====\n");
	 	printf("1 - Depositar\n");
   		printf("2 - Sacar\n");
        printf("3 - Ver saldo\n");
        printf("4 - Sair\n");
        printf("Escolha uma op��o: ");
        scanf("%d", &opcao);

        if(opcao == 1){
            printf("O��o Depositar selecionada\n");
        }
        else if(opcao == 2){
            printf("Op��o Sacar selecionada\n");
        }
        else if(opcao == 3){
            printf("Op��o Ver saldo selecionada\n");
        }
        else if(opcao == 4){
            printf("Saindo do sistema...\n");
        }
        else{
            printf("Op��o inv�lida!\n");
        }
    }

    return 0;
}




