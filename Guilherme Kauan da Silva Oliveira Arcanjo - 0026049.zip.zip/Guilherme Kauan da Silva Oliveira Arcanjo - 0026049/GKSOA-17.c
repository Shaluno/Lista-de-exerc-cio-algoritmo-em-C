#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-17 - Fatorial de um n�mero"
			"\nUm aluno de matem�tica precisa calcular o fatorial de alguns n�meros para resolver exerc�cios escolares."
			"\nO programa deve receber um n�mero e calcular seu fatorial utilizando for. \n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo
 int i, numero;
 int fatorial = 1; 
 
 	printf("\nDigite um n�mero e descubra o seu fatorial: ");
 		scanf("%d", &numero);
 
 	for(i = 1; i <= numero; i++){
 		fatorial = fatorial * i;
	 }
	 
	printf("\nO fatorial de %d �: %d.", numero, fatorial);
	 
return 0;

}
