#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-36 - Pedir senha at� acertar -- senha (1111) - com do... while");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int senha;

    do{
        printf("Digite a senha: ");
        scanf("%d", &senha);

        if(senha != 1111){
            printf("Senha incorreta!\n");
        }

    } while(senha != 1111);

    printf("Acesso liberado!\n");

    return 0;
}
