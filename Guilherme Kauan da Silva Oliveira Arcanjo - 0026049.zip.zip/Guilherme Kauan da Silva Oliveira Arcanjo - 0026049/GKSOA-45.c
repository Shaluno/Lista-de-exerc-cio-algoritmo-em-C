#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-45 - O Assistente de Dire��o (GPS Sem Mapa)."
			"\nUm rob� de entregas aut�nomo est� andando por uma f�brica. Ele l� placas com letras que "
			"indicam para qual dire��o ele deve virar nas esquinas dos corredores."
			"\n\nFa�a um programa que leia uma letra mai�scula digitada e exiba o comando de voz do rob�:"
			"\n\n'N': ''Seguir para o Norte.''"
			"\n'S': ''Seguir para o Sul.''"
			"\n'L': ''Virar � Leste (Direita).''"
			"\n'O': ''Virar � Oeste (Esquerda).''"
			"\n\Qualquer outra letra: ''''Comando inv�lido! Pare o rob�.''\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

  char direcao;

    printf("Digite a dire��o (N, S, L, O): ");
    scanf(" %c", &direcao); // espa�o antes do %c

    switch(direcao){

        case 'N':
            printf("Seguir para o Norte.\n");
            break;

        case 'S':
            printf("Seguir para o Sul.\n");
            break;

        case 'L':
            printf("Virar a Leste (Direita).\n");
            break;

        case 'O':
            printf("Virar a Oeste (Esquerda).\n");
            break;

        default:
            printf("Comando inv�lido! Pare o robo.\n");
    }

    return 0;
}
