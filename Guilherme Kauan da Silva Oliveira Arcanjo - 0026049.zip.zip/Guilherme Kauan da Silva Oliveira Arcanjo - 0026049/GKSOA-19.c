#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-19 - Quadrado dos n�meros de 1 a 10 --> Um professor quer demonstrar o conceito de pot�ncia ao quadrado para a turma."
			"\nO programa deve mostrar o quadrado de cada n�mero de 1 at� 10.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo
 int i;
 
 	for(i = 1; i <= 10; i++){
 		printf("\n%d^2 = %d\n", i, (i*i));
	 }
	 
	 
return 0;

}
