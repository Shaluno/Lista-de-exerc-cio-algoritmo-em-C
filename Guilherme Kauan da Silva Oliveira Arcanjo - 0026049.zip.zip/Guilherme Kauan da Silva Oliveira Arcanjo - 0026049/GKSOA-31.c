#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-31 - Contar d�gitos de um n�mero."
			"\nUm sistema banc�rio deseja identificar quantos d�gitos possui um n�mero informado."
			"\nO programa deve receber um n�mero positivo e mostrar quantos d�gitos ele possui.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int numero; 
int cont = 0;


    printf("Digite um numero positivo: ");
    scanf("%d", &numero);

    while(numero > 0){
        numero = numero / 10;
        cont++;
    }

    printf("\nQuantidade de digitos: %d\n", cont);

    return 0;

}
