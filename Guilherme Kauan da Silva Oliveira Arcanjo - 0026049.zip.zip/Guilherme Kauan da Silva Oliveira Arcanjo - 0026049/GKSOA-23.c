#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-23 - Contar at� 10 com while"
			"\nUma crian�a est� aprendendo contagem num�rica no computador."
			"\nO programa deve imprimir os n�meros de 1 at� 10 usando while.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo
int i = 1;

	while(i <= 10){
	printf("\n%d\n", i++);
	}

return 0;


}
