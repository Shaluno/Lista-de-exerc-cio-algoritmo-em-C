#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-28 - N�mero primo com while"
			"\nUm estudante deseja verificar se determinado n�mero � primo utilizando outro tipo de repeti��o."
			"\nO programa deve testar se o n�mero possui apenas dois divisores usando while.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

 int numero, i = 2, primo = 1;

    printf("Digite um n�mero: ");
    scanf("%d", &numero);

    if(numero <= 1){
        primo = 0;
    }

    while(i < numero){
        if(numero % i == 0){
            primo = 0;
        }
        i++;
    }

    if(primo == 1){
        printf("\nN�mero primo\n");
    } else {
        printf("\nN�o � primo\n");
    }

    return 0;
}
