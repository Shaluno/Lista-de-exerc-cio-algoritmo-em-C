#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-38 - Soma at� o n�mero ser m�ltiplo de 10 --> Um sistema de pontua��o recebe v�rios valores digitados pelo usu�rio."
			"\nOs n�meros devem ser somados continuamente at� que seja digitado um n�mero m�ltiplo de 10. Ao final, o "
			"programa deve mostrar a soma total dos valores informados.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int numero;
int soma = 0;


	do{
		printf("\n Digite um n�mero:");
			scanf("%d", &numero);
			soma = soma + numero;
	}while(numero % 10 != 0);
	
	printf("\nO resultado final da soma �: %d", soma);


return 0;
}
