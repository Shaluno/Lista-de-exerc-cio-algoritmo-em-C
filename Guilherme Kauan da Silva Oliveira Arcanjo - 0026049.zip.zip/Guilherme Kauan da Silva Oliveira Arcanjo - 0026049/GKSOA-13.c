#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-13 - Contar de 1 a 10 --> Um professor quer que o computador mostre automaticamente os"
			" n�meros usados em uma chamada de alunos."
			"\nO programa deve imprimir os n�meros de 1 at� 10 utilizando um la�o for.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int i;

	for(i = 1; i <=10; i++){
	printf("%d\n", i);
    }

return 0;

}
