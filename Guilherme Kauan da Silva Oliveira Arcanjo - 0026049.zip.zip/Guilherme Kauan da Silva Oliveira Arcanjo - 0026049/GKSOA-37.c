#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-37 - Contagem regressiva de 10 at� 1 --> Uma corrida escolar utiliza uma contagem regressiva antes da largada."
			"\nO programa deve mostrar os n�meros de 10 at� 1 em ordem decrescente utilizando do...while.");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int i = 10;

	do{
	
		printf("\n%d\n", i);
		i--;
		
	} while(i > 0);

return 0;

}

