#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-06 - Ordem crescente (tr�s n�meros) --> Durante uma competi��o escolar, tr�s alunos obtiveram pontua��es diferentes."
			"\nO sistema precisa organizar os valores do menor para o maior para facilitar a classifica��o."
			"\nO programa deve receber tr�s n�meros e exibi-los em ordem crescente. \n");
	printf("\n************************************************************************** ");


//In�cio do c�digo

int a, b, c;

	printf("\n\nDigite o primeiro n�mero: ");
		scanf("%d", &a);
	printf("\nDigite o segundo n�mero: ");
		scanf("%d", &b);
	printf("\nDigite o terceiro n�mero: ");
		scanf("%d", &c);
	
	if(a > b){
        a = a + b;
        b = a - b;
        a = a - b;
    }
    if(a > c){
        a = a + c;
        c = a - c;
        a = a - c;
    }
    if(b > c){
        b = b + c;
        c = b - c;
        b = b - c;
    }

    printf("\nOrdem crescente: %d %d %d\n", a, b, c);

	
}
