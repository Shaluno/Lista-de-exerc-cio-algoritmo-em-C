#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-10 -  Maior de dois n�meros --> Dois atletas registraram suas pontua��es em uma prova."
			"\nO sistema precisa identificar qual foi a maior pontua��o"
			"\nO programa deve receber dois n�meros e mostrar qual deles � o maior.\n");
	printf("\n************************************************************************** ");

//In�cio do c�digo

int a, b;

	printf("\nDigite o 1� n�mero: ");
		scanf("%d", &a);
	printf("\nDigite o 2� n�mero: ");
		scanf("%d", &b);
		
	if(a > b){
		printf("\n%d � maior que %d.", a, b);
	}else{
		printf("\n%d � maior que %d.", b, a);
	}
	
return 0;

}
