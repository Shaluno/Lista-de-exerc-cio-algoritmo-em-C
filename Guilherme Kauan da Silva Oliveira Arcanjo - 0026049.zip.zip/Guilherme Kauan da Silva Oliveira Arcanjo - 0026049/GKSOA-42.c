#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-42 - O Menu do Fast-Food Digital --> Voc� est� programando o totem de autoatendimento de uma lanchonete. O cliente v� uma tela "
			"com as op��es de combos e digita o n�mero do seu pedido."
			"\nO Exerc�cio: Crie um algoritmo que leia um n�mero inteiro de 1 a 4 correspondente ao combo escolhido e mostre o nome do prato e o valor:"
			"\n\n1: *Combo Hamb�rguer + Batata + Refri - R$ 30,00"
			"\n2: *Combo Pizza Brotinho + Refri - R$ 25,00"
			"\n3: *Combo Salada + Suco Natural - R$ 22,00"
			"\n4: *Combo Balde de Frango + Molho - R$ 35,00"
			"\n\nCaso digite qualquer outro n�mero (Default): ''Op��o inv�lida! Escolha de 1 a 4.''.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int opcao;

printf("Escolha um combo (1 a 4): ");
    scanf("%d", &opcao);

    switch(opcao){

        case 1:
            printf("Combo Hamburguer + Batata + Refri - R$ 30,00\n");
            break;

        case 2:
            printf("Combo Pizza Brotinho + Refri - R$ 25,00\n");
            break;

        case 3:
            printf("Combo Salada + Suco Natural - R$ 22,00\n");
            break;

        case 4:
            printf("Combo Balde de Frango + Molho - R$ 35,00\n");
            break;

        default:
            printf("Op��oo inv�lida! Escolha de 1 a 4.\n");
    }

    return 0;
}



