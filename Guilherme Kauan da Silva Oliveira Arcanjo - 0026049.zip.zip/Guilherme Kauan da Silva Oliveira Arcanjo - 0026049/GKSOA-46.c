#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-46 - O Validador de Dias �teis."
			"\nO sistema de catracas de uma empresa precisa saber se um funcion�rio pode entrar no pr�dio."
			"\nNo s�bado e no domingo a empresa fecha, e a entrada s� � permitida de segunda a sexta-feira."
			"\nO Exerc�cio: Crie um script que receba um n�mero de 1 a 7 (onde 1 � Domingo, 2 � Segunda, e " 
			"assim por diante). O programa deve agrupar os casos e exibir se � um dia de trabalho ou descanso:"
			"\n\n2, 3, 4, 5, 6: Exibir ''Dia �til. Acesso liberado para o trabalho.''"
            "\n1, 7: Exibir ''Fim de Semana. Pr�dio fechado.''"
			"\nOutros n�meros: ''N�mero de dia inv�lido.''''\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int dia;

    printf("Digite um n�mero (1 a 7): ");
    scanf("%d", &dia);

    switch(dia){

        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            printf("Dia �til. Acesso liberado para o trabalho.\n");
            break;

        case 1:
        case 7:
            printf("Fim de Semana. Predio fechado.\n");
            break;

        default:
            printf("N�mero de dia invalido.\n");
    }

    return 0;
}

