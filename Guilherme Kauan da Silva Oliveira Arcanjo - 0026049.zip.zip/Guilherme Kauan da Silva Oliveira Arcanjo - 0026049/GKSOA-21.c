#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-21 - Verificar se um n�mero � primo --> Um estudante est� aprendendo sobre n�meros primos e quer automatizar a verifica��o."
			"\nO programa deve receber um n�mero e informar se ele � primo utilizando for.");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo
int numero, i;
int primo = 1;

    printf("\nDigite um n�mero: ");
    scanf("%d", &numero);

    if(numero <= 1){
        primo = 0;
    }else{
        for(i = 2; i < numero; i++){
            if(numero % i == 0){
                primo = 0;
                break;
            }
        }
    }

    if(primo == 1){
        printf("\nO n�mero %d � PRIMO.\n", numero);
    } else{
        printf("\nO n�mero %d N�O � primo.\n", numero);
    }

}
