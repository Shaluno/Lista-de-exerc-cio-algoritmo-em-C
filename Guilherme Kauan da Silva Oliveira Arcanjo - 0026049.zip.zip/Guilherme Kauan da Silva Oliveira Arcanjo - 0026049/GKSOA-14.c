#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL,"portuguese");
	
	printf("\n************************************************************************ \n");	
	printf("\n* Aluno: GUILHERME KAUAN DA SILVA OLIVEIRA ARCANJO - RA: 0026049       *\n ");
	printf("\n* Programa GKSOA-14 - Tabuada de um n�mero --> Um estudante est� treinando matem�tica e" 
			" deseja visualizar rapidamente a tabuada de um n�mero."
			"\nO programa deve receber um n�mero digitado pelo usu�rio e mostrar sua tabuada de 1 a 10 usando for.\n");
	printf("\n**************************************************************************\n\n");

//In�cio do c�digo

int i, numero;

 printf("DIGITE UM N�MERO E DESCUBRA SUA TABUADA DE DE 1 A 10: ");
 	scanf("%d", &numero);
 	
 	for(i = 1; i <=10; i++){
 		printf("\n%d x %d = %d\n  ", numero, i, numero * i);
	 }
	 
return 0;

}
